package lesson1;

public class Team {
}
