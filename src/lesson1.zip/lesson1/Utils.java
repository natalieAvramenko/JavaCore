package lesson1;

public class Utils {
    public static void makeAnimalOlder(Animal animal) {
        animal.setAge(animal.getAge() + 1);
    }
}
