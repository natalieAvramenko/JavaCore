package lesson2;

public class OneOrBothSidesAreNegativeException extends Exception {
    public OneOrBothSidesAreNegativeException(String s) {
        super(s);
    }
}
